#!/bin/bash

echo "Running Python Tests for SMK.DEV TSA..."
echo "========================================"

# Jalankan semua test
python3 run_tests.py

echo ""
echo "Test completed!"
